<?php
header('Content-Type: application/json');

// Database connection details
$servername = "localhost";
$username = "rcocwiki_thru";
$password = "Password#110";
$dbname = "rcocwiki_thru";

// Create a new database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die(json_encode(array("error" => "Database connection failed: " . $conn->connect_error)));
}

// Validate and retrieve the site parameter from the URL
$site = isset($_GET['site']) ? $_GET['site'] : '';
$table = "";

// Map the site parameter to the corresponding database table
if ($site == 'site1') {
    $table = "site1_vehicle_data";
} elseif ($site == 'site2') {
    $table = "site2_vehicle_data";
} elseif ($site == 'site3') {
    $table = "site3_vehicle_data";
} else {
    die(json_encode(array("error" => "Invalid site parameter")));
}

// Fetch all data from the specified table
$sql = "SELECT * FROM $table";
$result = $conn->query($sql);

// Fetch counts of 'In' and 'Out' entries for the site
$count_sql = "SELECT
                 COUNT(*) as total,
                 SUM(CASE WHEN in_out = 'In' THEN 1 ELSE 0 END) as in_count,
                 SUM(CASE WHEN in_out = 'Out' THEN 1 ELSE 0 END) as out_count
              FROM $table";
$count_result = $conn->query($count_sql);

// Initialize data storage variables
$data = array();
$total = 0;
$in_count = 0;
$out_count = 0;

// Populate count variables
if ($count_result && $count_result->num_rows > 0) {
    $counts = $count_result->fetch_assoc();
    $total = $counts['total'];
    $in_count = $counts['in_count'];
    $out_count = $counts['out_count'];
}

// Fetch all rows and store in the data array
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Calculate cut-through traffic events
$cut_throughs = findCutThroughs($conn);

// Return JSON response with data and cut-through details
echo json_encode(array(
    "data" => $data,
    "total" => $total,
    "in_count" => $in_count,
    "out_count" => $out_count,
    "cut_throughs" => $cut_throughs
));

// Close the database connection
$conn->close();

/**
 * Function to find all possible cut-through traffic events between sites.
 */
function findCutThroughs($conn) {
    // Define initial cut-through data structure
    $cut_throughs = array(
        "site1_to_site2" => array("count" => 0, "avg_speed" => 0),
        "site2_to_site1" => array("count" => 0, "avg_speed" => 0),
        "site1_to_site3" => array("count" => 0, "avg_speed" => 0),
        "site3_to_site1" => array("count" => 0, "avg_speed" => 0),
        "site2_to_site3" => array("count" => 0, "avg_speed" => 0),
        "site3_to_site2" => array("count" => 0, "avg_speed" => 0)
    );

    // Define distances between sites (in miles)
    $distances = array(
        "site1_to_site2" => 0.4,
        "site2_to_site1" => 0.4,
        "site2_to_site3" => 0.4,
        "site3_to_site2" => 0.4,
        "site1_to_site3" => 0.6,
        "site3_to_site1" => 0.6
    );

    // Fetch 'In' and 'Out' entries for each site
    $in_entries = array(
        "site1" => fetchEntries($conn, "site1_vehicle_data", "In"),
        "site2" => fetchEntries($conn, "site2_vehicle_data", "In"),
        "site3" => fetchEntries($conn, "site3_vehicle_data", "In")
    );

    $out_entries = array(
        "site1" => fetchEntries($conn, "site1_vehicle_data", "Out"),
        "site2" => fetchEntries($conn, "site2_vehicle_data", "Out"),
        "site3" => fetchEntries($conn, "site3_vehicle_data", "Out")
    );

    // Calculate cut-throughs between each pair of sites
    $cut_throughs["site1_to_site2"] = calculateCutThroughSpeed($in_entries["site1"], $out_entries["site2"], $distances["site1_to_site2"]);
    $cut_throughs["site2_to_site1"] = calculateCutThroughSpeed($in_entries["site2"], $out_entries["site1"], $distances["site2_to_site1"]);
    $cut_throughs["site2_to_site3"] = calculateCutThroughSpeed($in_entries["site2"], $out_entries["site3"], $distances["site2_to_site3"]);
    $cut_throughs["site3_to_site2"] = calculateCutThroughSpeed($in_entries["site3"], $out_entries["site2"], $distances["site3_to_site2"]);
    $cut_throughs["site1_to_site3"] = calculateCutThroughSpeed($in_entries["site1"], $out_entries["site3"], $distances["site1_to_site3"]);
    $cut_throughs["site3_to_site1"] = calculateCutThroughSpeed($in_entries["site3"], $out_entries["site1"], $distances["site3_to_site1"]);

    return $cut_throughs;
}

/**
 * Fetch 'In' or 'Out' entries for a specific site table.
 */
function fetchEntries($conn, $table, $in_out) {
    $entries = array();
    $sql = "SELECT * FROM $table WHERE in_out = '$in_out'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $entries[] = $row;
        }
    }
    return $entries;
}

/**
 * Calculate cut-through count and average speed between 'In' and 'Out' entries.
 */
function calculateCutThroughSpeed($in_entries, $out_entries, $distance) {
    $cut_through_count = 0;
    $total_speed = 0;
    $max_time_diff = 600;  // Maximum time difference (10 minutes in seconds)

    foreach ($in_entries as $in_entry) {
        foreach ($out_entries as $out_entry) {
            // Create combined fields for exact matching
            $in_combined = strtolower(trim($in_entry['plate']) . trim($in_entry['vehicle_type']) . trim($in_entry['vehicle_color']));
            $out_combined = strtolower(trim($out_entry['plate']) . trim($out_entry['vehicle_type']) . trim($out_entry['vehicle_color']));

            // Check for an exact match of the combined fields
            if ($in_combined === $out_combined) {
                $time_diff = strtotime($out_entry['time']) - strtotime($in_entry['time']);

                // Verify the time difference is within the allowed limit
                if ($time_diff > 0 && $time_diff <= $max_time_diff) {
                    $cut_through_count++;
                    $speed_mph = ($distance / ($time_diff / 3600));  // Calculate speed in MPH
                    $total_speed += $speed_mph;
                }
                break;  // Exit inner loop once a match is found
            }
        }
    }

    $avg_speed = ($cut_through_count > 0) ? ($total_speed / $cut_through_count) : 0;
    return array("count" => $cut_through_count, "avg_speed" => round($avg_speed, 2));
}
?>
