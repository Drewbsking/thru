<?php
header('Content-Type: application/json');

// Database connection details
$servername = "localhost";
$username = "rcocwiki_thru";
$password = "Password#110";
$dbname = "rcocwiki_thru";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(array("error" => "Connection failed: " . $conn->connect_error)));
}

// Determine which table to query based on the site parameter
$site = $_GET['site'] ?? '';  // Use the site parameter from the URL query
$table = '';

if ($site == 'site1') {
    $table = "site1_vehicle_data";
} elseif ($site == 'site2') {
    $table = "site2_vehicle_data";
} elseif ($site == 'site3') {
    $table = "site3_vehicle_data";
}

// Check if a valid table is set
if ($table != "") {
    // Fetch data from the selected site table
    $sql = "SELECT * FROM $table";
    $result = $conn->query($sql);

    $data = array();
    $in_count = 0;
    $out_count = 0;

    // Retrieve data and count 'In' and 'Out' entries
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
            if ($row['in_out'] == 'In') {
                $in_count++;
            } elseif ($row['in_out'] == 'Out') {
                $out_count++;
            }
        }
    }

    // Return data as JSON response
    echo json_encode(array("data" => $data, "in_count" => $in_count, "out_count" => $out_count));
} else {
    echo json_encode(array("error" => "Invalid site parameter"));
}

$conn->close();
?>
